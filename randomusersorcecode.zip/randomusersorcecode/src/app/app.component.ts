import { Component } from "@angular/core";


@Component({
  selector: "app-swiper-example",
  templateUrl: "app.component.html",
  styleUrls: [ './app.component.css' ]
})
export class AppComponent {}
